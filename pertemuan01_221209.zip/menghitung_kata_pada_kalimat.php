<?php
// buat inputan, tipe text
// lalu diproses oleh php
// kemudian tampilkan dengan fungsi str_word_count()
// $a = 'kata-kata ini akan dihitung';
// echo str_word_count($a);
?>