<html>
  <head>
    <title>Latihan</title>
  </head>
  <body>
    paragraph1<br>paragraph2
  </body>
</html>