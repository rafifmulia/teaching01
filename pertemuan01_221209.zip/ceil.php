<!-- buat inputan angka -->
<!-- bulatkan ke teratas menggunakan fungsi ceil -->
<?php
  echo ceil(1.4);
?>