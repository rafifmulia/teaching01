<?php
// buat inputan, tipe text
// lalu diproses oleh php
// kemudian tampilkan dengan fungsi var_dump()
?>