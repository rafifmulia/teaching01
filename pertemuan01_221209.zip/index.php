<html>
  <head>
    <title>Fungsi Ceil</title>
  </head>
  <body>
    <?php
      echo ceil(1.4);
    ?>
  </body>
</html>