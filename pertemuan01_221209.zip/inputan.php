<html>
  <head>
    <title>Inputan</title>
  </head>
  <body>
    <form method="post">
      Angka: <input type="number" name="angka1" required> <br>
      Tulisan: <input type="text" name="tulisan1" required> <br>
      <button type="submit">Kirim</button>
    </form>
  </body>
</html>