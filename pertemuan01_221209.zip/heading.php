<html>
  <head>
    <title>Latihan</title>
  </head>
  <body>
    <h1>Heading ukuran 1</h1>
    <h2>Heading ukuran 2</h2>
    <h3>Heading ukuran 3</h3>
    <h4>Heading ukuran 4</h4>
    <h5>Heading ukuran 5</h5>
    <h6>Heading ukuran 6</h6>
  </body>
</html>