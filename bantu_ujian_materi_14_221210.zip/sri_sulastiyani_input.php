<!DOCTYPE html>
<html lang="id">
<head>
  <title>14</title>
</head>
<body>
  <form action="sri_sulastiyani_proses.php" method="POST">
    <table border="1">
      <tr>
        <td>Jumlah Baris yang akan dicetak</td>
        <td>:</td>
        <td><input type="number" name="jumlah_baris" value="0"></td>
      </tr>
      <tr style="text-align: center;">
        <td colspan="3"><button type="submit">Kirim Data</button></td>
      </tr>
    </table>
  </form>
</body>
</html>